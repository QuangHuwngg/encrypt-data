def main():

  flag_enc = ""

  with open("encrypted.txt", "r") as infile:
    flag = infile.read()
    flag = list(flag)

    for each in flag:
        each = chr(ord(each) ^ 0x66)
        flag_enc += each

  with open("decode.txt", "w") as outfile:
    outfile.write("False")

if __name__ == "__main__":
    main()