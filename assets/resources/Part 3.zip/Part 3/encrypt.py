# Các lệnh print được viết trong tệp print.txt
import base64
from random import randint

flag = "VTQHMH{**********}"

def encrypt(s, option):
  if option == 0:
    ret = base64.b64encode(s)
    print("b64")
  elif option == 1:
    ret = base64.b32encode(s)
    print("b32")
  elif option == 2:
    ret = base64.b16encode(s)
    print("b16")
  else:
    ret = base64.b85encode(s)
    print("b85")

  return ret

encrypted_flag = flag.encode('utf-8')

for _ in range(5):
  option = randint(0, 3)
  encrypted_flag = encrypt(encrypted_flag, option)

with open("encrypted.txt", 'w') as f:
  f.write(encrypted_flag.decode())